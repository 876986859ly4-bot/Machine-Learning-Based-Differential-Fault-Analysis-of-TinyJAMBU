def filter_expression_by_variable(lines, specified_term):
    results = []
    for line in lines:
        if '=' not in line:
            continue

        var_name, expr = line.split('=', 1)
        var_name = var_name.strip()
        expr = expr.strip()

        terms = [term.strip() for term in expr.split('+') if term.strip()]
        filtered_terms = [term for term in terms if specified_term in term]

        if filtered_terms:
            new_expr = ' + '.join(filtered_terms)
            results.append(f'{var_name} = {new_expr}')
        # 删除 else 分支，不保留空表达式
    return results

# ===== 主程序：处理 S[0] 到 S[127] 并统一写入一个文件 =====
input_path = 'ANF/804-anf.txt'
output_path = '过滤结果_S0_S127_合集.txt'

with open(input_path, 'r', encoding='utf-8') as infile:
    all_lines = infile.readlines()

with open(output_path, 'w', encoding='utf-8') as outfile:
    for i in range(128):
        specified_variable = f'S[{i}]'
        outfile.write(f'=== 仅保留包含 {specified_variable} 的表达式 ===\n')
        filtered = filter_expression_by_variable(all_lines, specified_variable)
        for line in filtered:
            outfile.write(line + '\n')
        outfile.write('\n')  # 添加空行作为分隔

print(f'✅ 所有 S[0] 到 S[127] 的筛选结果已写入：{output_path}')
