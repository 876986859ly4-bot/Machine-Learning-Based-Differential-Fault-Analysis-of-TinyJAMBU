import re
import os

INPUT_FILE = '去除分区标志并替换S值.txt'
OUTPUT_FILE = '过滤结果_去除纯数字并反转1项.txt'

expression_pattern = re.compile(r'^\s*([01])\s*=\s*(.*)$')
results = []

if not os.path.exists(INPUT_FILE):
    print(f"❌ 输入文件未找到：{INPUT_FILE}")
    exit(1)

with open(INPUT_FILE, 'r', encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue

        match = expression_pattern.match(line)
        if not match:
            continue  # 不匹配就跳过（也可以保留原行）

        lhs, rhs = match.group(1), match.group(2).strip()

        if re.fullmatch(r'[01]', rhs):
            continue  # 纯数字 RHS 跳过

        terms = [t.strip() for t in rhs.split('+') if t.strip()]
        new_terms = []
        flip_count = 0

        for term in terms:
            if term == '1':
                flip_count += 1
            else:
                new_terms.append(term)

        new_lhs = lhs
        if flip_count % 2 == 1:
            new_lhs = '0' if lhs == '1' else '1'

        if new_terms:
            results.append(f"{new_lhs} = {' + '.join(new_terms)}")
        else:
            results.append(new_lhs)

print(f"✅ 共写入 {len(results)} 条结果至：{OUTPUT_FILE}")
with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
    f.write('\n'.join(results))
