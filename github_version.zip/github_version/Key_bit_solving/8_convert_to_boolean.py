import re

# 读取文件内容
def read_file(file_path):
    with open(file_path, 'r', encoding='utf-8') as file:
        return file.readlines()

# 写入格式化后的内容到新文件
def write_to_file(output_path, data):
    with open(output_path, 'w', encoding='utf-8') as file:
        file.write('\n'.join(data))

# 清洗和转换表达式
def process_expression(expression):
    # 跳过分区标志等无效行
    if "===" in expression or not expression.strip():
        return None

    # 替换 S[xx] 为 Sxx，K[xx] 为 Kxx
    expression = re.sub(r'S\[(\d+)\]', r'S\1', expression)
    expression = re.sub(r'K\[(\d+)\]', r'K\1', expression)

    # 处理等式
    parts = expression.split('=')
    if len(parts) == 2:
        left_side = parts[0].strip()
        right_side = parts[1].strip()

        # 如果左边是数字（0 或 1），加上引号也输出
        formatted_expr = f'("{left_side}", "{right_side}"),'
        return formatted_expr
    return None

# 主程序
def transform_file(input_file_path, output_file_path):
    lines = read_file(input_file_path)
    formatted_lines = []

    for line in lines:
        processed_line = process_expression(line.strip())
        if processed_line:  # 只添加非空处理结果
            formatted_lines.append(processed_line)

    write_to_file(output_file_path, formatted_lines)

# 使用示例
input_file_path = 'new_过滤结果_去除纯数字并反转1项.txt'
output_file_path = '代入后转换成boolean.txt'
transform_file(input_file_path, output_file_path)

print("✅ 转换完成，结果已保存至 '代入后转换成boolean.txt'.")
