import re

# 判断每个加法项是否都只含 ≤3 个变量（S[...] 或 K[...]）
def is_valid_cubic_equation(equation):
    if "=" not in equation:
        return False

    _, rhs = equation.split("=", 1)
    rhs = rhs.strip()

    # 拆分每个加法项
    terms = re.split(r'\s*\+\s*', rhs)

    for term in terms:
        # 查找这一项中的变量（S[...] 或 K[...]）
        variables = re.findall(r'S\[\d+\]|K\[\d+\]', term)
        if len(variables) > 4:
            return False  # 如果某一项有超过3个变量，就不是合法的
    return True  # 所有项都满足 ≤3 变量

# 读取文本内容
def read_processed_equations(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        return file.readlines()

# 提取三次方程
def extract_cubic_equations(file_path):
    equations = read_processed_equations(file_path)

    result = []
    for line in equations:
        stripped_line = line.strip()
        if stripped_line == "":
            continue
        if "===" in line:
            result.append(line)
        elif is_valid_cubic_equation(stripped_line):
            result.append(line)
    return result

# 写入三次方程到新文件
def write_cubic_equations(file_path, cubic_equations):
    new_file_path = "cubic_" + file_path
    with open(new_file_path, "w", encoding="utf-8") as file:
        file.writelines(cubic_equations)
    print(f"✅ 三次方程已保存为: {new_file_path}")

# 主流程
def process_cubic_equations(file_path):
    cubic_equations = extract_cubic_equations(file_path)
    write_cubic_equations(file_path, cubic_equations)

# 文件路径
file_path = "过滤结果_去除自引用_结果.txt"
process_cubic_equations(file_path)
