import re

INPUT_FILE = '过滤结果_S0_S127_合集.txt'
OUTPUT_FILE = '过滤结果_去除自引用_结果.txt'

# 匹配分区标题，比如：=== 仅保留包含 S[15] 的表达式 ===
partition_pattern = re.compile(r'(===\s*仅保留包含 S\[(\d+)\] 的表达式\s*===)')
# 匹配表达式行，例如：S[12] = S[3]*S[15] + S[4]
expression_pattern = re.compile(r'^(S\[\d+\])\s*=\s*(.*)$')

with open(INPUT_FILE, 'r', encoding='utf-8') as f:
    content = f.read()

parts = partition_pattern.split(content)

results = []

# 每 3 个为一组：header、index、body
for i in range(1, len(parts) - 2, 3):
    header = parts[i].strip()
    si_index = int(parts[i + 1])
    body = parts[i + 2].strip()
    current_si = f"S[{si_index}]"

    results.append(header)
    lines = body.splitlines()

    for line in lines:
        line = line.strip()
        expr_match = expression_pattern.match(line)
        if expr_match:
            lhs, rhs = expr_match.group(1), expr_match.group(2).strip()

            xor_terms = [term.strip() for term in rhs.split('+') if term.strip()]
            new_terms = []

            for term in xor_terms:
                factors = [f.strip() for f in term.split('*')]

                if len(factors) == 1 and factors[0] == current_si:
                    # 单独的自引用，替换为 1
                    new_terms.append('1')
                else:
                    # 去除 S[i]
                    cleaned_factors = [f for f in factors if f != current_si]
                    if cleaned_factors:
                        new_terms.append('*'.join(cleaned_factors))
                    # 否则整个 term 被忽略

            if new_terms:
                results.append(f"{lhs} = {' + '.join(new_terms)}")
    results.append('')  # 分区之间保留空行

with open(OUTPUT_FILE, 'w', encoding='utf-8') as f:
    f.write('\n'.join(results))
