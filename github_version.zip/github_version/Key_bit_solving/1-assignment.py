import os
import re

def load_assignments_from_file(filename, offset):
    pattern = re.compile(r'.*?(S)(\d+):\s*✅ 唯一，必须为 (True|False)')
    assignments = {}
    conflicts = []

    with open(filename, 'r', encoding='utf-8') as f:
        for lineno, line in enumerate(f, start=1):
            line = line.strip()
            match = pattern.match(line)
            if not match:
                continue

            original_index = int(match.group(2))
            new_index = original_index - offset
            if new_index < 0:
                print(f"[⚠️跳过] 文件 {filename} 第 {lineno} 行 S{original_index} - {offset} 为负数")
                continue

            var = f"S{new_index}"
            value = (match.group(3) == "True")

            if var in assignments:
                if assignments[var] != value:
                    conflicts.append((var, assignments[var], value, filename, lineno))
            else:
                assignments[var] = value

    return assignments, conflicts

def process_all_files(target_value, output_filename="assignment.txt"):
    output_dir = "./output"
    if not os.path.exists(output_dir):
        print(f"❌ 文件夹 '{output_dir}' 不存在")
        return

    result_files = [f for f in os.listdir(output_dir) if re.match(r'^\d+-output\.txt$', f)]
    final_assignments = {}
    all_conflicts = []

    for fname in sorted(result_files):
        base = int(fname.split("-")[0])
        if base >= target_value:
            continue  # 跳过大于等于目标值的文件

        offset = target_value - base
        full_path = os.path.join(output_dir, fname)
        print(f"[处理中] {fname}，偏移量 = {offset}")

        file_assignments, file_conflicts = load_assignments_from_file(full_path, offset)

        for var, val in file_assignments.items():
            if var in final_assignments:
                if final_assignments[var] != val:
                    all_conflicts.append((var, final_assignments[var], val, fname, '合并'))
            else:
                final_assignments[var] = val

        all_conflicts.extend(file_conflicts)

    with open(output_filename, 'w', encoding='utf-8') as fout:
        fout.write(f"===== 所有文件中解析到的“✅ 唯一”S赋值（已编号调整） =====\n")
        for var in sorted(final_assignments, key=lambda x: int(x[1:])):
            fout.write(f"{var} = {final_assignments[var]}\n")

        fout.write("\n")
        if all_conflicts:
            fout.write("⚠️ 以下是冲突变量：\n")
            for var, old_val, new_val, fname, line in all_conflicts:
                fout.write(f"  {var}：已为 {old_val}，但在 {fname} 第 {line} 行为 {new_val}\n")
        else:
            fout.write("✅ 没有检测到冲突，所有赋值一致。\n")

    print(f"[完成] 共提取 {len(final_assignments)} 条唯一 S 赋值，结果写入 {output_filename}")

def main():
    try:
        target = int(input("请输入目标值（如 860）：").strip())
        process_all_files(target)
    except ValueError:
        print("❌ 输入无效，必须是整数")

if __name__ == "__main__":
    main()
