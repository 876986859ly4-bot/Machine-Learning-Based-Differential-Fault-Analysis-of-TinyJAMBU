from z3 import *
import re
from functools import reduce

# ——————————————
# 1. 读取布尔表达式并解析
# ——————————————
def load_equations(filename):
    """
    从文件中读取所有 ("期望值", "表达式字符串") 形式的元组。
    """
    equations = []
    with open(filename, "r", encoding="utf-8") as f:
        content = f.read()
    # 正则匹配所有 ("1", "……") 或 ("0", "……") 的条目
    matches = re.findall(r'\("([01])",\s*"([^"]+)"\)', content)
    for label, expr in matches:
        equations.append((label.strip(), expr.strip()))
    return equations

# ——————————————
# 2. 提取所有出现过的变量名（排除常量“1”“0”）
# ——————————————
def collect_var_names(equations):
    """
    从表达式中提取所有形如 S<number> 或 K<number> 的变量名，
    返回一个集合，用于后续创建 Z3 Bool。
    """
    var_names = set()
    pattern = re.compile(r'([SK]\d+)')
    for _, expr in equations:
        # 查找所有 Sxx 或 Kxx
        found = pattern.findall(expr)
        var_names.update(found)
    return var_names

# ——————————————
# 3. 将单条布尔表达式（含 '*'、'+'、'1'、'0'）解析为 Z3 BoolExpr
# ——————————————
def parse_expr(expr_str, z3_vars):
    """
    把形如 "S3*S31*S116 + S3*1*S116 + … + K89" 转成 Z3 表达式。
    规则：
      '*' 表示布尔与 (And)
      '+' 表示布尔异或 (Xor)
      '1'、'0' 分别视为 BoolVal(True)/BoolVal(False)
      其他如 'S3','K89' 对应 z3_vars["S3"], z3_vars["K89"]
    """
    # 1) 去掉空格
    expr = expr_str.replace(" ", "")
    # 2) 按 '+' 拆分成若干“XOR 项”
    xor_terms = expr.split('+')
    z3_terms = []

    for term in xor_terms:
        # term 里可能有 '*'，也可能只有一个因子
        factors = term.split('*')
        z3_factors = []
        for f in factors:
            f = f.strip()
            if f == "1":
                z3_factors.append(BoolVal(True))
            elif f == "0":
                z3_factors.append(BoolVal(False))
            else:
                # 此时 f 应当是 Sxx 或 Kxx
                if f not in z3_vars:
                    raise ValueError(f"变量未定义: {f}")
                z3_factors.append(z3_vars[f])
        # 如果这一项只有一个因子，则直接使用它，否则用 And(...)
        if len(z3_factors) == 1:
            z3_terms.append(z3_factors[0])
        else:
            z3_terms.append(And(*z3_factors))

    # 如果只一个 XOR 项，则直接返回；否则把它们用 Xor 串联起来
    if len(z3_terms) == 1:
        return z3_terms[0]
    else:
        return reduce(lambda x, y: Xor(x, y), z3_terms)

# ——————————————
# 4. 主流程：构建并求解 Z3 模型，同时做“唯一性分析”
# ——————————————
def main():
    output_filename = "856-output.txt"

    eqs = load_equations("代入后转换成boolean.txt")
    if not eqs:
        print("未读取到任何 (期望, 表达式) 元组，请检查文件格式。")
        return

    var_names = collect_var_names(eqs)
    z3_vars = {name: Bool(name) for name in var_names}

    solver = Solver()
    parsed_equations = []

    for idx, (lhs, rhs_expr) in enumerate(eqs):
        try:
            z3_expr = parse_expr(rhs_expr, z3_vars)
        except ValueError as e:
            print(f"[ERROR] 第 {idx+1} 条表达式解析失败：{e}")
            return

        expected_bool = (lhs == "1")
        solver.add(z3_expr == expected_bool)
        parsed_equations.append((z3_expr, expected_bool))

        if solver.check() == unsat:
            print(f"❌ 冲突在第 {idx+1} 条 ({lhs} = {rhs_expr})")
            return

    # 如果整体可满足，进行唯一性分析
    if solver.check() == sat:
        with open(output_filename, "w", encoding="utf-8") as fout:
            fout.write("🔎 唯一性分析：\n")
            for var in sorted(var_names):
                s_true = Solver()
                for expr, expect in parsed_equations:
                    s_true.add(expr == expect)
                s_true.add(z3_vars[var] == True)
                true_sat = (s_true.check() == sat)

                s_false = Solver()
                for expr, expect in parsed_equations:
                    s_false.add(expr == expect)
                s_false.add(z3_vars[var] == False)
                false_sat = (s_false.check() == sat)

                if true_sat and not false_sat:
                    fout.write(f"{var}: ✅ 唯一，必须为 True\n")
                elif false_sat and not true_sat:
                    fout.write(f"{var}: ✅ 唯一，必须为 False\n")
                elif true_sat and false_sat:
                    fout.write(f"{var}: ❌ 不唯一（可为 True 或 False）\n")
                else:
                    fout.write(f"{var}: ❌ 无解（矛盾）\n")
        print(f"[完成] 唯一性分析结果已写入 {output_filename}")
    else:
        print("❌ UNSAT：整个方程组无解（即存在矛盾）。")


if __name__ == "__main__":
    main()
