import re

# 1. 从 assignment.txt 中解析 S[i] -> '1' or '0'
def load_s_assignments(assignment_file):
    """
    读取 assignment.txt，将所有 S<i> = True/False 的行解析为:
        'S116' -> '1'
    """
    s_map = {}
    with open(assignment_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line or not line.startswith('S'):
                continue
            if '=' not in line:
                continue
            name, value = map(str.strip, line.split('=', 1))
            if name.startswith('S'):
                if value == 'True':
                    s_map[name] = '1'
                elif value == 'False':
                    s_map[name] = '0'
    return s_map

# 2. 替换表达式中的 S[...] 为 '1' 或 '0'
def substitute_s_values(expr_line, s_map):
    if '=' not in expr_line:
        return expr_line
    left, right = expr_line.split('=', 1)
    left = left.strip()
    right = right.strip()
    for s_name, bit_val in s_map.items():
        index = s_name[1:]  # e.g., S70 → 70
        pattern = re.compile(r'S\[' + re.escape(index) + r'\]')
        right = pattern.sub(bit_val, right)
    return f"{left} = {right}"

# 3. 主流程：处理表达式并替换
def main():
    input_file = "过滤结果_去除纯数字并反转1项.txt"
    output_file = "new_过滤结果_去除纯数字并反转1项.txt"
    assignment_file = "assignment.txt"

    s_map = load_s_assignments(assignment_file)
    print(f"[INFO] 从 {assignment_file} 中解析到 {len(s_map)} 个 S[...] 赋值。")

    with open(input_file, 'r', encoding='utf-8') as fin, \
         open(output_file, 'w', encoding='utf-8') as fout:
        for lineno, line in enumerate(fin, start=1):
            line = line.rstrip('\n')
            new_line = substitute_s_values(line, s_map)
            fout.write(new_line + "\n")

    print(f"[INFO] 替换完成，结果已保存至 '{output_file}'。")

if __name__ == "__main__":
    main()
