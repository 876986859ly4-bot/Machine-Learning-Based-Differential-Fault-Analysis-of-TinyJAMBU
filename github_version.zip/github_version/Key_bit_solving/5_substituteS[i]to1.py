import re

# 加载 test.txt 文件中每行的 32 位二进制为列表
def load_test_values(test_file):
    test_values = []
    with open(test_file, 'r') as f:
        for line in f:
            if 'XOR Result' in line:
                bin_str = line.split(':')[-1].replace(' ', '').strip()
                bits = [int(b) for b in bin_str]
                test_values.append(bits)
    return test_values

# 主处理函数
def process_expression_file(expression_file, test_file, output_file):
    test_values = load_test_values(test_file)
    output_lines = []

    current_si = None

    with open(expression_file, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()

            # 检测是否为新的分区标志行
            match = re.match(r"=== 仅保留包含 S\[(\d+)\] 的表达式 ===", line)
            if match:
                current_si = int(match.group(1))
                continue  # 不输出该分区标志

            # 如果是表达式行，进行处理
            if '=' in line and current_si is not None:
                left, right = line.split('=', 1)
                left = left.strip()
                right = right.strip()

                # 提取 S[j] 的 j
                var_match = re.match(r'S\[(\d+)\]', left)
                if var_match:
                    s_index = int(var_match.group(1))
                    # 如果在 S[64]~S[95] 范围内，用 test.txt 中对应分区的值替换
                    if 64 <= s_index <= 95:
                        replacement = str(test_values[current_si][s_index - 64])
                        output_lines.append(f"{replacement} = {right}")
                    else:
                        output_lines.append(f"{left} = {right}")

    with open(output_file, 'w', encoding='utf-8') as out:
        out.write('\n'.join(output_lines))

    print(f"✅ 完成处理并写入：{output_file}")

# === 文件路径配置 ===
expression_file = 'cubic_过滤结果_去除自引用_结果.txt'
test_file = 'test-data\\test-1r-804.txt'
output_file = '去除分区标志并替换S值.txt'

process_expression_file(expression_file, test_file, output_file)
