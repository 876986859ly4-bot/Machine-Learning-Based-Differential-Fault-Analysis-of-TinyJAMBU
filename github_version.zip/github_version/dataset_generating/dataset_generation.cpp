#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <iomanip>
#include <cstring>
#include <iostream>  // 包含 iostream 头文件



#define FrameBitsIV  0x10  
#define FrameBitsAD  0x30  
#define FrameBitsPC  0x50  //Framebits for plaintext/ciphertext      
#define FrameBitsFinalization 0x70       

#define NROUND1 128*5 
#define NROUND2 128*8 


/*no-optimized date update function*/
void state_update(unsigned int* state, const unsigned char* key, unsigned int number_of_steps)
{
    unsigned int i;
    unsigned int t1, t2, t3, t4, feedback;
    for (i = 0; i < (number_of_steps >> 5); i++)
    {

        t1 = (state[1] >> 15) | (state[2] << 17);  // 47 = 1*32+15 
        t2 = (state[2] >> 6) | (state[3] << 26);  // 47 + 23 = 70 = 2*32 + 6 
        t3 = (state[2] >> 21) | (state[3] << 11);  // 47 + 23 + 15 = 85 = 2*32 + 21      
        t4 = (state[2] >> 27) | (state[3] << 5);   // 47 + 23 + 15 + 6 = 91 = 2*32 + 27 
        feedback = state[0] ^ t1 ^ (~(t2 & t3)) ^ t4 ^ ((unsigned int*)key)[i & 3];
        // shift 32 bit positions 
        state[0] = state[1]; state[1] = state[2]; state[2] = state[3];
        state[3] = feedback;
    }
}


void state_update_v2(unsigned int* state, const unsigned char* key, unsigned int number_of_steps, int control, int p)
{
    unsigned int i;
    unsigned int t1, t2, t3, t4, feedback;
    for (i = 0; i < (number_of_steps >> 5); i++)
    {


        t1 = (state[1] >> 15) | (state[2] << 17);  // 47 = 1*32+15 
        t2 = (state[2] >> 6) | (state[3] << 26);  // 47 + 23 = 70 = 2*32 + 6 
        t3 = (state[2] >> 21) | (state[3] << 11);  // 47 + 23 + 15 = 85 = 2*32 + 21      
        t4 = (state[2] >> 27) | (state[3] << 5);   // 47 + 23 + 15 + 6 = 91 = 2*32 + 27 
        feedback = state[0] ^ t1 ^ (~(t2 & t3)) ^ t4 ^ ((unsigned int*)key)[i & 3];
        // shift 32 bit positions 
        state[0] = state[1]; state[1] = state[2]; state[2] = state[3];
        state[3] = feedback;

        // 26*32 = 832 在832轮结束后 833 轮开始前进行注入
        if (i == 26 && control == 1) {

            int index = p / 32;          // 确定 state 的索引
            int bit_offset = p % 32;     // 确定具体位偏移
            state[index] ^= (1U << bit_offset); // 翻转对应比特

        }
    }
}


void state_update_bitwise(unsigned int* state, const unsigned char* key, unsigned int number_of_steps, int control, int p, int rou)
{
    unsigned int i;
    for (i = 0; i < number_of_steps; i++)
    {

        if (i == rou && control == 1) {
            int index = p / 32;
            int bit_offset = p % 32;
            state[index] ^= (1U << bit_offset);

        }
        // 提取关键位
        unsigned int s_0 = (state[0] >> 0) & 1;
        unsigned int s_47 = (state[1] >> 15) & 1;
        unsigned int s_70 = (state[2] >> 6) & 1;
        unsigned int s_85 = (state[2] >> 21) & 1;
        unsigned int s_91 = (state[2] >> 27) & 1;

        // key[i % 128] 每轮从key中取一位
        unsigned int kword = ((unsigned int*)key)[(i >> 5) & 3];
        unsigned int kbit = (kword >> (i % 32)) & 1;

        unsigned int feedback = s_0 ^ s_47 ^ (~(s_70 & s_85) & 1) ^ s_91 ^ kbit;

        // 整体左移1位
        state[0] = (state[0] >> 1) | ((state[1] & 1) << 31);
        state[1] = (state[1] >> 1) | ((state[2] & 1) << 31);
        state[2] = (state[2] >> 1) | ((state[3] & 1) << 31);
        state[3] = (state[3] >> 1) | (feedback << 31);


    }


}


// The initialization  
/* The input to initialization is the 128-bit key; 96-bit IV;*/
void initialization(const unsigned char* key, const unsigned char* iv, unsigned int* state)
{
    int i;

    //initialize the state as 0  
    for (i = 0; i < 4; i++) state[i] = 0;

    //update the state with the key  
    state_update(state, key, NROUND2);

    //introduce IV into the state  
    for (i = 0; i < 3; i++)
    {
        state[1] ^= FrameBitsIV;
        state_update(state, key, NROUND1);
        state[3] ^= ((unsigned int*)iv)[i];
    }
}

//process the associated data   
void process_ad(const unsigned char* k, const unsigned char* ad, unsigned long long adlen, unsigned int* state)
{
    unsigned long long i;
    unsigned int j;

    for (i = 0; i < (adlen >> 2); i++)
    {
        state[1] ^= FrameBitsAD;
        state_update(state, k, NROUND1);
        state[3] ^= ((unsigned int*)ad)[i];
    }

    // if adlen is not a multiple of 4, we process the remaining bytes
    if ((adlen & 3) > 0)
    {
        state[1] ^= FrameBitsAD;
        state_update(state, k, NROUND1);
        for (j = 0; j < (adlen & 3); j++)  ((unsigned char*)state)[12 + j] ^= ad[(i << 2) + j];
        state[1] ^= adlen & 3;
    }
}

//encrypt plaintext   
int crypto_aead_encrypt(
    unsigned char* c, unsigned long long* clen,
    const unsigned char* m, unsigned long long mlen,
    const unsigned char* ad, unsigned long long adlen,
    const unsigned char* nsec,
    const unsigned char* npub,
    const unsigned char* k,
    int p,
    int control,
    int rou
)
{
    unsigned long long i;
    unsigned int j;
    unsigned char mac[8];
    unsigned int state[4];

    //initialization stage
    initialization(k, npub, state);

    //process the associated data   
    process_ad(k, ad, adlen, state);




    //process the plaintext    
    for (i = 0; i < (mlen >> 2); i++)
    {
        state[1] ^= FrameBitsPC;

        state_update_bitwise(state, k, NROUND2, control, p, rou);

        state[3] ^= ((unsigned int*)m)[i];
        ((unsigned int*)c)[i] = state[2] ^ ((unsigned int*)m)[i];

        unsigned int val = ((unsigned int*)c)[i];
    }


    // if mlen is not a multiple of 4, we process the remaining bytes
    if ((mlen & 3) > 0)
    {
        state[1] ^= FrameBitsPC;
        state_update(state, k, NROUND2);
        for (j = 0; j < (mlen & 3); j++)
        {
            ((unsigned char*)state)[12 + j] ^= m[(i << 2) + j];
            c[(i << 2) + j] = ((unsigned char*)state)[8 + j] ^ m[(i << 2) + j];
        }
        state[1] ^= mlen & 3;
    }

    //finalization stage, we assume that the tag length is 8 bytes
    state[1] ^= FrameBitsFinalization;
    state_update(state, k, NROUND2);
    ((unsigned int*)mac)[0] = state[2];

    state[1] ^= FrameBitsFinalization;
    state_update(state, k, NROUND1);
    ((unsigned int*)mac)[1] = state[2];

    *clen = mlen + 8;
    for (j = 0; j < 8; j++) c[mlen + j] = mac[j];

    return 0;
}

//decrypt a message
int crypto_aead_decrypt(
    unsigned char* m, unsigned long long* mlen,
    unsigned char* nsec,
    const unsigned char* c, unsigned long long clen,
    const unsigned char* ad, unsigned long long adlen,
    const unsigned char* npub,
    const unsigned char* k
)
{
    unsigned long long i;
    unsigned int j, check = 0;
    unsigned char mac[8];
    unsigned int state[4];

    *mlen = clen - 8;

    //initialization stage
    initialization(k, npub, state);

    //process the associated data   
    process_ad(k, ad, adlen, state);

    //process the ciphertext    
    for (i = 0; i < (*mlen >> 2); i++)
    {
        state[1] ^= FrameBitsPC;
        state_update(state, k, NROUND2);
        ((unsigned int*)m)[i] = state[2] ^ ((unsigned int*)c)[i];
        state[3] ^= ((unsigned int*)m)[i];

    }
    // if mlen is not a multiple of 4, we process the remaining bytes
    if ((*mlen & 3) > 0)
    {
        state[1] ^= FrameBitsPC;
        state_update(state, k, NROUND2);
        for (j = 0; j < (*mlen & 3); j++)
        {
            m[(i << 2) + j] = c[(i << 2) + j] ^ ((unsigned char*)state)[8 + j];
            ((unsigned char*)state)[12 + j] ^= m[(i << 2) + j];
        }
        state[1] ^= *mlen & 3;
    }

    //finalization stage, we assume that the tag length is 8 bytes
    state[1] ^= FrameBitsFinalization;
    state_update(state, k, NROUND2);
    ((unsigned int*)mac)[0] = state[2];

    state[1] ^= FrameBitsFinalization;
    state_update(state, k, NROUND1);
    ((unsigned int*)mac)[1] = state[2];

    //verification of the authentication tag   
    for (j = 0; j < 8; j++) { check |= (mac[j] ^ c[clen - 8 + j]); }
    if (check == 0) return 0;
    else return -1;
}


void random_key(unsigned char* key, int size) {

    for (int i = 0; i < size; i++) {
        key[i] = rand() & 0xFF;

    }
}

void random_nonce(unsigned char* nonce, int size) {
    for (int i = 0; i < size; i++) {
        nonce[i] = rand() & 0xFF;
    }
}

void print_key(unsigned char* key, int size) {
    printf("Generated key: ");
    for (int i = 0; i < size; i++) {
        printf("%02X ", key[i]);  // 以十六进制格式打印
    }
    printf("\n");
}

void print_binary(FILE* fp, unsigned char byte) {
    for (int i = 0; i <= 7; i++) {
        // 检查当前位是否为 1
        fprintf(fp, "%d", (byte >> i) & 1);
    }
}

void fault_simulation(FILE* fp, int p, int r, unsigned char* key, unsigned char* nonce) {

    for (int k = 1; k <= 10000; k++) {

        /*
        // 定义输入数据
        unsigned char key[16] = {
             0x00, 0x01, 0x02, 0x03,
               0x04, 0x05, 0x06, 0x07,
              0x08, 0x09, 0x0A, 0x0B,
             0x0C, 0x0D, 0x0E, 0x0F
        };
        */
        int num = 16;
        random_key(key, num);
        /*
         unsigned char nonce[12] = {
           0x00, 0x01, 0x02, 0x03,
           0x04, 0x05, 0x06, 0x07, 
           0x08, 0x09, 0x0A, 0x0B
        };     
        */
       
        int num2 = 12;
        random_nonce(nonce, num2);


        unsigned char plaintext[4] = {
           0xA1, 0xB2, 0xC3, 0xD4,
        };

        unsigned long long plaintext_len = 4;

        const unsigned char* associated_data = NULL; // 空关联数据，指针为 NULL
        unsigned long long associated_data_len = 0; // 关联数据长度为 0

        unsigned char ciphertext_1[12]; // 用于存储加密结果
        unsigned char ciphertext_2[12]; // 用于存储加密结果
        unsigned long long clen = 12; // 密文长度


        int c = 0;
        // 调用加密函数
        int result_1 = crypto_aead_encrypt(
            ciphertext_1, &clen,
            plaintext, plaintext_len,
            associated_data, associated_data_len,
            NULL, // 不使用密钥管理
            nonce,
            key,
            p,
            c,
            r
        );


        int c2 = 1;
        // 调用加密函数
        int result_2 = crypto_aead_encrypt(
            ciphertext_2, &clen,
            plaintext, plaintext_len,
            associated_data, associated_data_len,
            NULL, // 不使用密钥管理
            nonce,
            key,
            p,
            c2,
            r
        );


        // 计算 ciphertext_1 和 ciphertext_2 的异或
        unsigned char xor_result[12] = { 0 };
        for (unsigned long long i = 0; i < clen; i++) {
            xor_result[i] = ciphertext_1[i] ^ ciphertext_2[i];
        }

        //打印 p 即注入错误的位置
        fprintf(fp, "%d\t", p);
        //fprintf(fp, "%d\t", r);

        // 打印 XOR 结果
        fprintf(fp, "XOR Result (First 32 bits in binary): ");
        unsigned long long bit_count = 0;

        // 只打印前 32 位
        for (unsigned long long i = 0; i < clen; i++) {
            // 如果已经打印了 32 位，停止
            if (bit_count >= 32) break;

            print_binary(fp, xor_result[i]);
            bit_count += 8;  // 每打印一个字节，增加 8 位

            // 只打印前 32 位，因此最后不会换行太多
            if (bit_count < 32) {
                fprintf(fp, " ");
            }
        }

        fprintf(fp, "\n");
    }
}

// 打印 state
void print_state(const char* label, const unsigned int* state) {
    std::cout << label << ":\n";
    for (int i = 0; i < 4; ++i) {
        std::cout << "state[" << i << "] = 0x" << std::hex << std::uppercase << std::setw(8)
            << std::setfill('0') << state[i] << std::endl;
    }
    std::cout << std::dec; // 恢复默认十进制
}


void write_to_file(int k, unsigned char* key, int key_len, unsigned char* nonce, int nonce_len) {
    FILE* fp = fopen("C:\\Users\\武汉彭于晏\\Desktop\\test\\output_keys_nonces.txt", "a"); // 以追加方式写入文件
    if (fp == NULL) {
        perror("Failed to open file");
        return;
    }

    fprintf(fp, "===== Set %d =====\n", k);

    fprintf(fp, "Key: ");
    for (int i = 0; i < key_len; i++) {
        fprintf(fp, "%02X ", key[i]);
    }
    fprintf(fp, "\n");

    fprintf(fp, "Nonce: ");
    for (int i = 0; i < nonce_len; i++) {
        fprintf(fp, "%02X ", nonce[i]);
    }
    fprintf(fp, "\n\n");

    fclose(fp);
}


int main() {

    srand(time(NULL));
    char filename[100];  // 用于存储动态生成的文件名

    for (int k = 1; k <= 1; k++) {
        
        // 定义输入数据
        unsigned char key[16] = {
             0x00, 0x01, 0x02, 0x03,
             0x04, 0x05, 0x06, 0x07,
             0x08, 0xf9, 0x0A, 0x0B,
             0x0C, 0x0D, 0x0E, 0x0F
        };
        int num = 16;
       //random_key(key, num);
        //print_key(key, num);

        unsigned char nonce[12] = {
          0x00, 0x01, 0x02, 0x03,
          0x04, 0x05, 0x06, 0x07,
          0x08, 0x09, 0x0A, 0x0B
        };
        int num2 = 12;

        for (int r = 856; r <= 856; r = r + 1) {

            // 根据 r 构造文件名，例如 text-800.txt
            sprintf(filename, "C:\\Users\\武汉彭于晏\\Desktop\\test\\test-10000\\test-1r-real-%d.txt",r);

            FILE* fp = fopen(filename, "a");  // 使用追加模式写入
            if (!fp) {
                perror("无法打开输出文件");
                exit(1);
            }
            int i = 0;
            for (int i = 0; i <= 127; i++) {


                fault_simulation(fp, i, r, key, nonce);

            }
        }
    }
    return 0;
}



