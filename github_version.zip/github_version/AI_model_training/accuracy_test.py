import torch
import torch.nn as nn
from torch.utils.data import DataLoader, Dataset
import numpy as np

# ----- Dataset 类（与你训练用的一致）-----
class FaultDataset(Dataset):
    def __init__(self, data_path):
        data = np.load(data_path)
        self.x = torch.tensor(data['inputs'], dtype=torch.float32)
        self.y = torch.tensor(data['labels'], dtype=torch.long)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]

# ----- 模型结构（与你训练的一致）-----
class FaultClassifier(nn.Module):
    def __init__(self):
        super(FaultClassifier, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(32, 128),
            nn.ReLU(),
            nn.Dropout(p=0.1),
            nn.Linear(128, 256),
            nn.ReLU(),
            nn.Dropout(p=0.1),
            nn.Linear(256, 128),
            nn.ReLU(),
            nn.Dropout(p=0.1),
            nn.Linear(128, 128)
        )

    def forward(self, x):
        return self.model(x)

# ----- 评估函数 -----
def evaluate(model, dataloader, device):
    model.eval()
    correct = 0
    total = 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            outputs = model(x)
            predicted = torch.argmax(outputs, dim=1)
            correct += (predicted == y).sum().item()
            total += y.size(0)
    accuracy = correct / total
    return accuracy

# ----- 主入口 -----
if __name__ == "__main__":
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 加载测试集数据文件
    test_dataset = FaultDataset("fault_data.npz")
    test_loader = DataLoader(test_dataset, batch_size=128, shuffle=False)

    # 初始化并加载模型
    model = FaultClassifier().to(device)
    model.load_state_dict(torch.load("best_fault_classifier.pt", map_location=device))

    # 评估并输出准确率
    acc = evaluate(model, test_loader, device)
    print(f"✅ 测试集准确率: {acc:.4f}")
