import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Dataset
import numpy as np

# ----- Custom Dataset Class -----
class FaultDataset(Dataset):
    def __init__(self, data_path):
        data = np.load(data_path)
        self.x = torch.tensor(data['inputs'], dtype=torch.float32)
        self.y = torch.tensor(data['labels'], dtype=torch.long)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]

# ----- Optimized MLP Model -----
class FaultClassifier(nn.Module):
    def __init__(self):
        super(FaultClassifier, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(32, 256),
            nn.SiLU(),
            nn.Dropout(p=0.2),
            nn.Linear(256, 128),
            nn.SiLU(),
            nn.Dropout(p=0.2),
            nn.Linear(128, 128),
            nn.SiLU(),
            nn.Dropout(p=0.2),
            nn.Linear(128, 128),
        )

    def forward(self, x):
        return self.model(x)

# ----- Training Loop -----
def train(model, dataloader, optimizer, criterion, device):
    model.train()
    total_loss, correct = 0, 0
    for x, y in dataloader:
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        logits = model(x)
        loss = criterion(logits, y)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
        optimizer.step()

        total_loss += loss.item() * x.size(0)
        pred = torch.argmax(logits, dim=1)
        correct += (pred == y).sum().item()
    return total_loss / len(dataloader.dataset), correct / len(dataloader.dataset)

# ----- Evaluation -----
def evaluate(model, dataloader, criterion, device):
    model.eval()
    total_loss, correct = 0, 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            logits = model(x)
            loss = criterion(logits, y)
            total_loss += loss.item() * x.size(0)
            pred = torch.argmax(logits, dim=1)
            correct += (pred == y).sum().item()
    return total_loss / len(dataloader.dataset), correct / len(dataloader.dataset)

# ----- Main -----
if __name__ == "__main__":
    from sklearn.model_selection import train_test_split

    # Load and split data
    full_data = np.load("fault_data-816.npz")
    x_train, x_val, y_train, y_val = train_test_split(
        full_data['inputs'], full_data['labels'], test_size=0.2, random_state=42)

    np.savez("train_data.npz", inputs=x_train, labels=y_train)
    np.savez("val_data.npz", inputs=x_val, labels=y_val)

    train_dataset = FaultDataset("train_data.npz")
    val_dataset = FaultDataset("val_data.npz")

    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=64)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = FaultClassifier().to(device)

    # ----- Initial Training -----
    optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=3e-5)
    criterion = nn.CrossEntropyLoss(label_smoothing=0.05)

    print("\n--- Initial Training Stage ---\n")
    for epoch in range(20):
        train_loss, train_acc = train(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        print(f"Epoch {epoch+1:02d}: Train Loss={train_loss:.4f}, Acc={train_acc:.4f} | Val Loss={val_loss:.4f}, Acc={val_acc:.4f}")

    torch.save(model.state_dict(), "initial_fault_classifier.pt")

    # ----- Fine-tuning Stage -----
    print("\n--- Fine-tuning Stage (ReduceLROnPlateau + EarlyStopping) ---\n")
    optimizer = optim.AdamW(model.parameters(), lr=5e-5, weight_decay=1e-4)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(optimizer, factor=0.5, patience=3, verbose=True)

    best_acc = 0
    patience = 10
    counter = 0
    max_epochs = 100

    for epoch in range(max_epochs):
        train_loss, train_acc = train(model, train_loader, optimizer, criterion, device)
        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        scheduler.step(val_loss)

        print(f"FineTune Epoch {epoch+1:02d}: Train Loss={train_loss:.4f}, Acc={train_acc:.4f} | Val Loss={val_loss:.4f}, Acc={val_acc:.4f}")

        if val_acc > best_acc:
            best_acc = val_acc
            counter = 0
            torch.save(model.state_dict(), "best_fault_classifier.pt")
        else:
            counter += 1
            if counter >= patience:
                print(f"Early stopping triggered at FineTune Epoch {epoch+1}")
                break
