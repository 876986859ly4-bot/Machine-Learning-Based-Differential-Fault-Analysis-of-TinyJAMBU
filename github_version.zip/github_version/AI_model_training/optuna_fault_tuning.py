import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader
import numpy as np
import optuna
from sklearn.model_selection import train_test_split
from torch.utils.data import Dataset
import optuna.visualization as vis

# ----- Dataset -----
class FaultDataset(Dataset):
    def __init__(self, x, y):
        self.x = torch.tensor(x, dtype=torch.float32)
        self.y = torch.tensor(y, dtype=torch.long)

    def __len__(self):
        return len(self.x)

    def __getitem__(self, idx):
        return self.x[idx], self.y[idx]

# ----- Model -----
class FaultClassifier(nn.Module):
    def __init__(self, hidden1, hidden2, hidden3, dropout_rate, activation_fn):
        super(FaultClassifier, self).__init__()
        act = getattr(nn, activation_fn)()
        self.model = nn.Sequential(
            nn.Linear(32, hidden1),
            act,
            nn.Dropout(p=dropout_rate),
            nn.Linear(hidden1, hidden2),
            act,
            nn.Dropout(p=dropout_rate),
            nn.Linear(hidden2, hidden3),
            act,
            nn.Dropout(p=dropout_rate),
            nn.Linear(hidden3, 128),
        )

    def forward(self, x):
        return self.model(x)

# ----- Train / Eval -----
def train(model, dataloader, optimizer, criterion, device):
    model.train()
    correct, total_loss = 0, 0
    for x, y in dataloader:
        x, y = x.to(device), y.to(device)
        optimizer.zero_grad()
        out = model(x)
        loss = criterion(out, y)
        loss.backward()
        optimizer.step()
        total_loss += loss.item() * x.size(0)
        correct += (out.argmax(dim=1) == y).sum().item()
    return total_loss / len(dataloader.dataset), correct / len(dataloader.dataset)

def evaluate(model, dataloader, criterion, device):
    model.eval()
    correct, total_loss = 0, 0
    with torch.no_grad():
        for x, y in dataloader:
            x, y = x.to(device), y.to(device)
            out = model(x)
            loss = criterion(out, y)
            total_loss += loss.item() * x.size(0)
            correct += (out.argmax(dim=1) == y).sum().item()
    return total_loss / len(dataloader.dataset), correct / len(dataloader.dataset)

# ----- Optuna Objective -----
def objective(trial):
    # Hyperparameter space
    hidden1 = trial.suggest_categorical('hidden1', [128, 256, 512, 1024])
    hidden2 = trial.suggest_categorical('hidden2', [128, 256, 512, 1024])
    hidden3 = trial.suggest_categorical('hidden3', [128, 256, 512, 1024])
    dropout = trial.suggest_float('dropout', 0.1, 0.5)
    lr = trial.suggest_float('lr', 1e-5, 1e-3, log=True)
    weight_decay = trial.suggest_float('weight_decay', 1e-6, 1e-3, log=True)
    label_smooth = trial.suggest_float('label_smooth', 0.0, 0.1)
    activation_fn = trial.suggest_categorical('activation', ['ReLU', 'LeakyReLU', 'GELU'])

    model = FaultClassifier(hidden1, hidden2, hidden3, dropout, activation_fn).to(device)
    optimizer = optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    criterion = nn.CrossEntropyLoss(label_smoothing=label_smooth)

    for epoch in range(15):  # Keep short for tuning
        train(model, train_loader, optimizer, criterion, device)

    _, val_acc = evaluate(model, val_loader, criterion, device)
    return val_acc

# ----- Main -----
if __name__ == "__main__":
    # Load and split data
    full_data = np.load("fault_data-816.npz")
    x_train, x_val, y_train, y_val = train_test_split(
        full_data['inputs'], full_data['labels'], test_size=0.2, random_state=42)

    train_dataset = FaultDataset(x_train, y_train)
    val_dataset = FaultDataset(x_val, y_val)

    train_loader = DataLoader(train_dataset, batch_size=64, shuffle=True)
    val_loader = DataLoader(val_dataset, batch_size=64)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    study = optuna.create_study(direction='maximize')
    study.optimize(objective, n_trials=3)
    
    print("Best trial:")
    print(study.best_trial)
    # 绘制优化历史
    vis.plot_optimization_history(study)
    # 绘制超参数重要性
    vis.plot_param_importances(study)
    # 绘制参数关系图
    vis.plot_parallel_coordinate(study)