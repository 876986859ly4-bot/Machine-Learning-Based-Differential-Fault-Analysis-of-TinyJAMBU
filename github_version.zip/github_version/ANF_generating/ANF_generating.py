import re

# 创建布尔变量环
B = BooleanPolynomialRing(256, 'x')
vars = B.gens()  # 获取变量列表 x0 ~ x255

# 分离状态变量 S 和密钥变量 K
S = list(vars[:128])
K = list(vars[128:])

# 定义状态更新函数
def StateUpdate_symbolic(S, K, i):
    klen = len(K)
    ki = K[i % klen]
    feedback = S[0] + S[47] + (1 + S[70] * S[85]) + S[91] + ki
    S[:] = S[1:] + [feedback]

# 将表达式中的变量转换为 S[i] 或 K[i]
def expr_with_SK(expr):
    expr_str = str(expr)
    def replace_x(match):
        n = int(match.group(1))
        return f"S[{n}]" if n < 128 else f"K[{n - 128}]"
    return re.sub(r'x(\d+)', replace_x, expr_str)

# 运行 228 轮状态更新
for i in range(228):
    print(i)
    StateUpdate_symbolic(S, K, i)

# 将指定轮次的 S[64] 到 S[95] 状态写入文件
output_file = "796-anf.txt"
with open(output_file, "w", encoding="utf-8") as f:
    f.write(f"=== 第 {i+1} 轮 S[64] 到 S[95] 状态（标注 S/K 来源） ===\n\n")
    for idx in range(64,96):
        f.write(f"S[{idx}] = {expr_with_SK(S[idx])}\n\n")

print(f"状态表达式已写入文件：{output_file}")