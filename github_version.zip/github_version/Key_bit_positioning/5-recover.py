import torch
import torch.nn as nn
import itertools
import json

# ------------------ 模型结构 ------------------
class FaultClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.model = nn.Sequential(
            nn.Linear(32, 128), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(128, 256), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(256, 128), nn.ReLU(), nn.Dropout(0.1),
            nn.Linear(128, 128)
        )

    def forward(self, x):
        return self.model(x)

# ------------------ 加载样本 ------------------
def load_samples(txt_path):
    samples = []
    with open(txt_path, "r") as f:
        for line_num, line in enumerate(f, start=1):
            if "XOR Result" not in line or ":" not in line:
                continue
            try:
                label = int(line.split("\t")[0])
                bitstr = line.split(":")[1].strip().replace(" ", "")
                if len(bitstr) != 32:
                    continue
                tensor = torch.tensor([int(b) for b in bitstr], dtype=torch.float32)
                samples.append({
                    "tensor": tensor,
                    "true": label,
                    "bits": bitstr
                })
            except Exception as e:
                print(f"[!] 第{line_num}行解析失败：{e}")
                continue
    return samples

# ------------------ 预测并分桶 ------------------
def predict_and_bucket(model_path, txt_path):
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    model = FaultClassifier().to(device)
    model.load_state_dict(torch.load(model_path, map_location=device))
    model.eval()

    bucket = [[] for _ in range(128)]
    samples = load_samples(txt_path)

    with torch.no_grad():
        for s in samples:
            pred = torch.argmax(model(s["tensor"].unsqueeze(0).to(device)), 1).item()
            bucket[pred].append(s)
    return bucket

# ------------------ 简单重分配并收集选项 ------------------
def simple_reassign_with_choices(bucket, confusion_prob):
    empty = lambda: [i for i, b in enumerate(bucket) if not b]
    empties = set(empty())

    # 检查是否有超过2样本的桶
    for i, b in enumerate(bucket):
        if len(b) > 2:
            raise ValueError(f"桶{i}超过2个样本，无法处理")

    options = dict()  # 重复桶索引 -> [(空缺桶idx, 样本pos), ...]

    # 遍历重复桶
    for i, b in enumerate(bucket):
        if len(b) == 2:
            s1, s2 = b
            true1, true2 = s1['true'], s2['true']
            candidates = confusion_prob.get(str(i), [])
            # 过滤只保留空缺桶的候选
            possible_targets = [int(t) for t in candidates if int(t) in empties]
            if not possible_targets:
                continue
            bucket_options = []
            for t in possible_targets:
                # 两种放法：样本0放t 或 样本1放t
                bucket_options.append((t, 0))
                bucket_options.append((t, 1))
            options[i] = bucket_options

    empties = set(empty())  # 更新空缺桶
    return bucket, options, list(empties)

# ------------------ 根据选项枚举所有可能分配 ------------------
def enumerate_with_options(bucket, options, empties, out_prefix="predict"):
    repeat_indices = list(options.keys())
    if not repeat_indices:
        write_array(bucket, f"{out_prefix}-1.txt")
        print(f"✅ 已输出 1 个候选 predict 文件（无重复桶）")
        return

    choices_per_bucket = [options[idx] for idx in repeat_indices]

    total = 0
    for combo in itertools.product(*choices_per_bucket):
        new_bucket = [lst[:] for lst in bucket]

        # 清空所有重复桶
        for idx in repeat_indices:
            new_bucket[idx] = []

        used_empty_buckets = set()
        valid = True

        for repeat_idx, (empty_bucket_idx, sample_pos) in zip(repeat_indices, combo):
            if empty_bucket_idx in used_empty_buckets:
                valid = False  # 同一个空缺桶被重复使用
                break
            used_empty_buckets.add(empty_bucket_idx)

            samples_in_repeat = bucket[repeat_idx]
            sample_to_move = samples_in_repeat[sample_pos]
            new_bucket[empty_bucket_idx] = [sample_to_move]

            other_sample_pos = 1 - sample_pos
            other_sample = samples_in_repeat[other_sample_pos]
            new_bucket[repeat_idx].append(other_sample)

        if not valid:
            continue
        if any(len(b) > 1 for b in new_bucket):
            continue

        total += 1
        write_array(new_bucket, f"{out_prefix}-{total}.txt")

    print(f"✨ 生成 {total} 份可能的 predict-*.txt")

# ------------------ 写出文件 ------------------
def write_array(bucket, path):
    with open(path, 'w') as f:
        for idx, lst in enumerate(bucket):
            entry = lst[0]["bits"] if lst else "EMPTY"
            f.write(f"{idx}\t{entry}\n")

# ------------------ 主程序 ------------------
if __name__ == "__main__":
    confusion_prob = json.load(open("confusion_prob.json"))
    bucket = predict_and_bucket("best_fault_classifier.pt", "real-100/test-1r-real-5.txt")
    bucket, options, empties = simple_reassign_with_choices(bucket, confusion_prob)
    enumerate_with_options(bucket, options, empties, out_prefix="predict")
